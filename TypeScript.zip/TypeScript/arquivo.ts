function soma(a: number, b: number): number {
 return a + b;
}
console.log(soma(5, 10));// Erro detectado na compilação!