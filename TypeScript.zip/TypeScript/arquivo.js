function soma(a, b) {
    return a + b;
}
console.log(soma(5, 10)); // Erro detectado na compilação!
