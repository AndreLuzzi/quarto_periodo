import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  AngularAppEngine,
  InlineCriticalCssProcessor,
  PrerenderFallback,
  RenderMode,
  createRequestHandler,
  destroyAngularServerApp,
  extractRoutesAndCreateRouteTree,
  getOrCreateAngularServerApp,
  getRoutesFromAngularRouterConfig,
  provideServerRendering,
  setAngularAppEngineManifest,
  setAngularAppManifest,
  withAppShell,
  withRoutes
} from "./chunk-7JPX45TW.js";
import "./chunk-ZYAR7YWF.js";
import "./chunk-PMP5ZYIR.js";
import "./chunk-FZ5RJTUJ.js";
import "./chunk-JXDRPW4G.js";
import "./chunk-Y7IVMKPC.js";
import "./chunk-WSVWRSJX.js";
import "./chunk-6DU2HRTW.js";
export {
  AngularAppEngine,
  PrerenderFallback,
  RenderMode,
  createRequestHandler,
  provideServerRendering,
  withAppShell,
  withRoutes,
  InlineCriticalCssProcessor as ɵInlineCriticalCssProcessor,
  destroyAngularServerApp as ɵdestroyAngularServerApp,
  extractRoutesAndCreateRouteTree as ɵextractRoutesAndCreateRouteTree,
  getOrCreateAngularServerApp as ɵgetOrCreateAngularServerApp,
  getRoutesFromAngularRouterConfig as ɵgetRoutesFromAngularRouterConfig,
  setAngularAppEngineManifest as ɵsetAngularAppEngineManifest,
  setAngularAppManifest as ɵsetAngularAppManifest
};
